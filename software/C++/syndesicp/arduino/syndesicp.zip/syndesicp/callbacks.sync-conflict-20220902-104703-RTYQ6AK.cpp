/**
 * @file callbacks.cpp
 *
 * @brief Callbacks management
 *
 * @author Sébastien Deriaz
 * @date 31.08.2022
 */

#include "callbacks.hpp"

namespace syndesi {

Callbacks::Callbacks() {
    
}
//Callbacks callbacks;

} // namespace syndesi