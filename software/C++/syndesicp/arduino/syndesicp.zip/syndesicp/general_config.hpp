/* Please edit this file to configure how the syndesi library works
*  
* Disabled callback :
* //#define 
* Enabled callback
* #define
*
*/

/*
* HOST mode : can send commands (a computer for example)
*/
#define HOST_MODE

/*
* DEVICE mode : can receive commands (like a I²C interface, SPI interface, etc...)
*/
#define DEVICE_MODE

// Both can be activated at the same time to enable HYBRID mode