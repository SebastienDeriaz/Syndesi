/**
 * @file settings.hpp
 *
 * @brief Settings
 *
 * @ingroup syndesi
 *
 * @author Sébastien Deriaz
 * @date 22.08.2022
 */


#define CONTROLLER_MODE_POLL 2
#define CONTROLLER_MODE_WAIT 3
#define CONTROLLER_MODE_IRQ 4